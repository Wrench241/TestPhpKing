# TestPhpKing
Teste para vaga Php King

Desenvolvendo interface em Php em que você pode CADASTRAR, ALTERAR e EXCLUIR produtos.<br>
Banco de dados: MySql.<br>
Linguagem: Php.<br>
Framework: nenhum, como na descrição do teste.

# Banco de dados<br>
user: root<br>
pass: tt333<br>
server: localhost<br>
banco de dados: produtos<br>

Obrigado pela oportunidade KING.
